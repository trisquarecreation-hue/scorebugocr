# SCOREBUG OCR for Apple iOS (iPhone & iPad)

SCOREBUG OCR provides two ways to run on Apple iOS devices:

---

## Method 1: Instant iOS Web App (PWA) — No Mac/Xcode Required ⭐

You can install SCOREBUG OCR directly onto any iPhone or iPad in seconds without needing an Apple developer account, Mac, or Xcode.

### Steps:
1. Make sure your **Windows PC** and your **iPhone/iPad** are connected to the **same Wi-Fi network**.
2. Launch **SCOREBUG OCR** on your Windows PC.
3. In the right panel, go to **Outputs (vMix/OBS)** → **Web Server / iOS App**.
4. Check **Enable Web / Mobile Server** (running on port `8099`).
5. Open **Safari** on your iPhone or iPad.
6. Enter your PC's local IP address and port:
   ```text
   http://<YOUR-PC-IP>:8099/app
   ```
   *(Example: `http://192.168.1.100:8099/app`)*
7. Tap the **Share** button (box with an arrow pointing up at the bottom of Safari).
8. Scroll down and tap **"Add to Home Screen"** (➕).
9. Confirm the name **SCOREBUG OCR** and tap **Add**.

Now, **SCOREBUG OCR** appears on your iOS Home Screen with the official green & black digital scoreboard icon. When tapped, it opens full-screen like a native app without Safari address bars, complete with live OCR preview, scores, clock, period, and instant score increment/decrement buttons!

---

## Method 2: Native Swift / Xcode iOS App

If you want a native compiled iOS binary (.ipa) installed via Xcode or TestFlight:

### Prerequisites:
- A Mac running macOS 13+ with **Xcode 15+** installed.
- iOS device running iOS 15.0 or later.

### Project Files in `ios/`:
- `ios/ScoreBugOCR/ScoreBugOCRApp.swift` — Main SwiftUI application entry point.
- `ios/ScoreBugOCR/ContentView.swift` — Native WKWebView wrapper with auto-reconnection, pull-to-refresh, manual IP settings sheet, and error handling.
- `ios/ScoreBugOCR/Info.plist` — Local network permissions (`NSLocalNetworkUsageDescription`, `NSAppTransportSecurity`).
- `ios/ScoreBugOCR/Assets.xcassets` — Official SCOREBUG OCR app icon catalog.

### Build & Run Instructions:
1. Copy the `ios/` folder to your Mac.
2. Open Xcode, create a new iOS App project named `ScoreBugOCR`.
3. Add `ScoreBugOCRApp.swift`, `ContentView.swift`, and `Info.plist` to the project target.
4. Replace `Assets.xcassets` with the provided `Assets.xcassets`.
5. Under **Signing & Capabilities**, select your Apple Developer Team.
6. Connect your iPhone or iPad via USB / Wi-Fi and click **Run** (Cmd + R).

---

## Features on iOS:
- **Live Scoreboard HUD**: Home score, Away score, Clock, and Period.
- **Real-Time OCR Preview**: See the live binarized image feed from the scoreboard camera.
- **Mobile Touch Controls**: Manual clock pause/resume, +1/-1 score adjustments, and period change directly from your phone.
- **Instant vMix & OBS Sync**: Any changes made from your iPhone immediately propagate to vMix and OBS broadcast graphics.
