import SwiftUI
import WebKit

struct ContentView: View {
    @AppStorage("serverAddress") private var serverAddress: String = "192.168.1.100:8099"
    @AppStorage("autoConnect") private var autoConnect: Bool = true
    @State private var showingSettings = false
    @State private var tempAddress = ""
    @State private var webViewURL: URL? = nil
    @State private var isConnected = false
    @State private var isLoading = false
    @State private var errorMessage: String? = nil
    @State private var reloadTrigger = UUID()

    var body: some View {
        NavigationView {
            ZStack {
                Color(UIColor.systemBackground).ignoresSafeArea()

                if let url = webViewURL {
                    ScoreBugWebView(
                        url: url,
                        isLoading: $isLoading,
                        errorMessage: $errorMessage,
                        reloadTrigger: reloadTrigger
                    )
                    .ignoresSafeArea(.keyboard, edges: .bottom)
                } else {
                    welcomeView
                }

                if isLoading {
                    ProgressView("Connecting to SCOREBUG OCR...")
                        .padding()
                        .background(Material.regularMaterial)
                        .cornerRadius(12)
                        .shadow(radius: 8)
                }

                if let error = errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 38))
                            .foregroundColor(.orange)
                        Text("Connection Failed")
                            .font(.headline)
                        Text(error)
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.secondary)
                            .padding(.horizontal)

                        HStack(spacing: 16) {
                            Button("Settings") {
                                tempAddress = serverAddress
                                showingSettings = true
                            }
                            .buttonStyle(.bordered)

                            Button("Retry") {
                                errorMessage = nil
                                loadServer()
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(Color(red: 0.15, green: 0.75, blue: 0.2))
                        }
                    }
                    .padding(24)
                    .background(Material.thickMaterial)
                    .cornerRadius(16)
                    .shadow(radius: 12)
                    .padding()
                }
            }
            .navigationTitle("SCOREBUG OCR")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        reloadTrigger = UUID()
                    }) {
                        Image(systemName: "arrow.clockwise")
                            .foregroundColor(Color(red: 0.15, green: 0.75, blue: 0.2))
                    }
                }

                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        tempAddress = serverAddress
                        showingSettings = true
                    }) {
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(Color(red: 0.15, green: 0.75, blue: 0.2))
                    }
                }
            }
            .sheet(isPresented: $showingSettings) {
                settingsSheet
            }
        }
        .onAppear {
            if autoConnect && !serverAddress.isEmpty {
                loadServer()
            }
        }
    }

    var welcomeView: some View {
        VStack(spacing: 20) {
            Image(systemName: "sportscourt.fill")
                .font(.system(size: 64))
                .foregroundColor(Color(red: 0.15, green: 0.75, blue: 0.2))

            Text("SCOREBUG OCR")
                .font(.title)
                .fontWeight(.bold)

            Text("Connect to your SCOREBUG OCR Windows host to view live scores, monitor OCR detection, and control outputs.")
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal, 32)

            Button("Connect to Host") {
                tempAddress = serverAddress
                showingSettings = true
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(red: 0.15, green: 0.75, blue: 0.2))
            .controlSize(.large)
        }
    }

    var settingsSheet: some View {
        NavigationView {
            Form {
                Section(header: Text("Host Configuration")) {
                    TextField("e.g., 192.168.1.100:8099 or hostname:8099", text: $tempAddress)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .keyboardType(.URL)

                    Toggle("Auto-Connect on Launch", isOn: $autoConnect)
                }

                Section(footer: Text("Run SCOREBUG OCR on your Windows PC, enable the Web / Mobile Server in Outputs, and enter the PC's IP address and port here.")) {
                    Button("Save and Connect") {
                        serverAddress = tempAddress.trimmingCharacters(in: .whitespacesAndNewlines)
                        showingSettings = false
                        loadServer()
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                    .foregroundColor(Color(red: 0.15, green: 0.75, blue: 0.2))
                }
            }
            .navigationTitle("Connection Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        showingSettings = false
                    }
                }
            }
        }
    }

    private func loadServer() {
        var cleanAddress = serverAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        if !cleanAddress.starts(with: "http://") && !cleanAddress.starts(with: "https://") {
            cleanAddress = "http://" + cleanAddress
        }
        if !cleanAddress.contains(":", in: cleanAddress.index(cleanAddress.startIndex, offsetBy: 7)..<cleanAddress.endIndex) && !cleanAddress.contains(":8099") {
            cleanAddress += ":8099"
        }
        if !cleanAddress.hasSuffix("/app") && !cleanAddress.hasSuffix("/") {
            cleanAddress += "/app"
        } else if cleanAddress.hasSuffix("/") {
            cleanAddress += "app"
        }

        if let targetURL = URL(string: cleanAddress) {
            errorMessage = nil
            webViewURL = targetURL
            reloadTrigger = UUID()
        } else {
            errorMessage = "Invalid server address entered."
        }
    }
}

struct ScoreBugWebView: UIViewRepresentable {
    let url: URL
    @Binding var isLoading: Bool
    @Binding var errorMessage: String?
    let reloadTrigger: UUID

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.bounces = true

        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.handleRefreshControl(sender:)), for: .valueChanged)
        webView.scrollView.refreshControl = refreshControl

        let request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 8.0)
        webView.load(request)
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url || context.coordinator.lastReloadTrigger != reloadTrigger {
            context.coordinator.lastReloadTrigger = reloadTrigger
            let request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 8.0)
            uiView.load(request)
        }
    }

    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: ScoreBugWebView
        var lastReloadTrigger: UUID? = nil

        init(_ parent: ScoreBugWebView) {
            self.parent = parent
        }

        @objc func handleRefreshControl(sender: UIRefreshControl) {
            sender.endRefreshing()
            parent.reloadTrigger != UUID()
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.parent.isLoading = true
                self.parent.errorMessage = nil
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.parent.isLoading = false
                self.parent.errorMessage = nil
            }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.isLoading = false
                self.parent.errorMessage = error.localizedDescription
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.isLoading = false
                self.parent.errorMessage = error.localizedDescription
            }
        }
    }
}
