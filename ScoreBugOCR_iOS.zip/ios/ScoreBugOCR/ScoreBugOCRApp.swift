import SwiftUI

@main
struct ScoreBugOCRApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
